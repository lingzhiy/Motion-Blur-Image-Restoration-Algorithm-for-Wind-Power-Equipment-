import math
import torch
import numpy as np
from torch.nn import functional as F
from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module
from torch import nn
from torch.nn import init

class DepthOverparamConv2d(Module):

    __constants__ = ['stride', 'padding', 'dilation', 'groups',
                     'padding_mode', 'output_padding', 'in_channels',
                     'out_channels', 'kernel_size', 'depth_multiplier']

    def __init__(self, in_channels, out_channels, kernel_size=3, depth_multiplier=None,
                 stride=1, padding=1, dilation=1, groups=1, bias=False,
                 padding_mode='zeros', use_simam=False):
        super().__init__()

        # 参数验证
        if in_channels % groups != 0:
            raise ValueError('in_channels must be divisible by groups')
        if out_channels % groups != 0:
            raise ValueError('out_channels must be divisible by groups')

        valid_padding_modes = {'zeros', 'reflect', 'replicate', 'circular'}
        if padding_mode not in valid_padding_modes:
            raise ValueError(f"padding_mode  must {valid_padding_modes}")

        kernel_size = (kernel_size, kernel_size)
        stride = (stride, stride)
        padding = (padding, padding)
        dilation = (dilation, dilation)

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.dilation = dilation
        self.groups = groups
        self.padding_mode = padding_mode
        self._padding_repeated_twice = tuple(x for x in self.padding for _ in range(2))
        self.use_simam = use_simam

        M, N = self.kernel_size
        self.depth_multiplier = M * N if depth_multiplier is None or M * N <= 1 else depth_multiplier


        self.base_weights = Parameter(torch.Tensor(out_channels, in_channels // groups, self.depth_multiplier))
        init.kaiming_uniform_(self.base_weights, a=math.sqrt(5))


        if M * N > 1:
            self.depth_transform = Parameter(torch.Tensor(in_channels, M * N, self.depth_multiplier))
            init_zero = np.zeros([in_channels, M * N, self.depth_multiplier], dtype=np.float32)
            self.depth_transform.data = torch.from_numpy(init_zero)


            eye = torch.reshape(torch.eye(M * N, dtype=torch.float32), (1, M * N, M * N))
            diag_init = eye.repeat((in_channels, 1, self.depth_multiplier // (M * N)))

            if self.depth_multiplier % (M * N) != 0:
                zeros = torch.zeros([in_channels, M * N, self.depth_multiplier % (M * N)])
                self.diag_matrix = Parameter(torch.cat([diag_init, zeros], dim=2), requires_grad=False)
            else:
                self.diag_matrix = Parameter(diag_init, requires_grad=False)

        if use_simam:
            self.simam = ChannelAttentionModule()


        if bias:
            self.bias = Parameter(torch.Tensor(out_channels))
            fan_in, _ = init._calculate_fan_in_and_fan_out(self.base_weights)
            bound = 1 / math.sqrt(fan_in)
            init.uniform_(self.bias, -bound, bound)
        else:
            self.register_parameter('bias', None)

    def _conv_forward(self, input, weight):
        if self.padding_mode != 'zeros':
            return F.conv2d(F.pad(input, self._padding_repeated_twice, mode=self.padding_mode),
                            weight, self.bias, self.stride,
                            (0, 0), self.dilation, self.groups)
        return F.conv2d(input, weight, self.bias, self.stride,
                        self.padding, self.dilation, self.groups)

    def forward(self, input):
        M, N = self.kernel_size
        output_shape = (self.out_channels, self.in_channels // self.groups, M, N)

        if M * N > 1:

            D = self.depth_transform + self.diag_matrix
            W = torch.reshape(self.base_weights,
                              (self.out_channels // self.groups, self.in_channels, self.depth_multiplier))

            transformed_weights = torch.reshape(
                torch.einsum('ims,ois->oim', D, W),
                output_shape
            )
        else:
            transformed_weights = torch.reshape(self.base_weights, output_shape)


        if self.use_simam:
            weights_part1, weights_part2 = torch.chunk(transformed_weights, 2, dim=2)
            transformed_weights = torch.cat([self.simam(weights_part1), weights_part2], dim=2)

        return self._conv_forward(input, transformed_weights)

    def extra_repr(self):
        return (f'{self.in_channels}, {self.out_channels}, kernel_size={self.kernel_size}'
                f', stride={self.stride}, padding={self.padding}, dilation={self.dilation}'
                f', groups={self.groups}, bias={self.bias is not None}'
                f', padding_mode={self.padding_mode}')


class DepthOverparamConv2dEval(Module):

    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1,
                 padding=1, dilation=1, groups=1, bias=False, padding_mode='zeros'):
        super().__init__()

        kernel_size = (kernel_size, kernel_size)
        stride = (stride, stride)
        padding = (padding, padding)
        dilation = (dilation, dilation)

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.dilation = dilation
        self.groups = groups
        self.padding_mode = padding_mode
        self._padding_repeated_twice = tuple(x for x in self.padding for _ in range(2))

        self.weights = Parameter(torch.Tensor(out_channels, in_channels // groups, *kernel_size))
        init.kaiming_uniform_(self.weights, a=math.sqrt(5))
        self.register_parameter('bias', None)

    def _conv_forward(self, input, weight):
        if self.padding_mode != 'zeros':
            return F.conv2d(F.pad(input, self._padding_repeated_twice, mode=self.padding_mode),
                            weight, None, self.stride,
                            (0, 0), self.dilation, self.groups)
        return F.conv2d(input, weight, None, self.stride,
                        self.padding, self.dilation, self.groups)

    def forward(self, input):
        return self._conv_forward(input, self.weights)


class ChannelAttentionModule(nn.Module):

    def __init__(self, lambda_param=1e-4):
        super().__init__()
        self.activation = nn.Sigmoid()
        self.lambda_param = lambda_param

    def forward(self, x):
        batch, channels, height, width = x.size()
        n_pixels = height * width - 1

        mean = x.mean(dim=[2, 3], keepdim=True)
        variance = (x - mean).pow(2)
        denominator = 4 * (variance.sum(dim=[2, 3], keepdim=True) / n_pixels + self.lambda_param)

        attention_weights = variance / denominator + 0.5
        return x * self.activation(attention_weights)