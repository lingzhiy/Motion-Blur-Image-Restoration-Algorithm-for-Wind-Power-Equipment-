from layers import *


class EncoderBlock(nn.Module):
    def __init__(self, out_channels, num_res=8, ResBlock=ResBlock):
        super(EncoderBlock, self).__init__()
        self.res_layers = nn.Sequential(*[ResBlock(out_channels) for _ in range(num_res)])

    def forward(self, x):
        return self.res_layers(x)


class DecoderBlock(nn.Module):
    def __init__(self, channels, num_res=8, ResBlock=ResBlock):
        super(DecoderBlock, self).__init__()
        self.res_layers = nn.Sequential(*[ResBlock(channels) for _ in range(num_res)])

    def forward(self, x):
        return self.res_layers(x)


class FeatureFusion(nn.Module):
    def __init__(self, in_channels, out_channels, BasicConv=BasicConv):
        super(FeatureFusion, self).__init__()
        self.conv = nn.Sequential(
            BasicConv(in_channels, out_channels, kernel_size=1, stride=1, relu=True),
            BasicConv(out_channels, out_channels, kernel_size=3, stride=1, relu=False)
        )

    def forward(self, x1, x2, x4):
        x = torch.cat([x1, x2, x4], dim=1)
        return self.conv(x)


class ShallowFeatureExtractor(nn.Module):
    def __init__(self, out_planes, BasicConv=BasicConv, in_channels=3):
        super(ShallowFeatureExtractor, self).__init__()
        self.main = nn.Sequential(
            BasicConv(in_channels, out_planes // 4, kernel_size=3, stride=1, relu=True),
            BasicConv(out_planes // 4, out_planes // 2, kernel_size=1, stride=1, relu=True),
            BasicConv(out_planes // 2, out_planes // 2, kernel_size=3, stride=1, relu=True),
            BasicConv(out_planes // 2, out_planes - in_channels, kernel_size=1, stride=1, relu=True)
        )
        self.conv = BasicConv(out_planes, out_planes, kernel_size=1, stride=1, relu=False)

    def forward(self, x):
        x = torch.cat([x, self.main(x)], dim=1)
        return self.conv(x)


class FeatureAttention(nn.Module):
    def __init__(self, channels, BasicConv=BasicConv):
        super(FeatureAttention, self).__init__()
        self.merge = BasicConv(channels, channels, kernel_size=3, stride=1, relu=False)

    def forward(self, x1, x2):
        x = x1 * x2
        out = x1 + self.merge(x)
        return out


class DeepRFTBase(nn.Module):
    def __init__(self, num_res=8, inference=False, base_channel=32):
        super(DeepRFTBase, self).__init__()
        self.inference = inference

        if not inference:
            BasicConv = BasicConv_do
            ResBlock = ResBlock_do_fft_bench
        else:
            BasicConv = BasicConv_do_eval
            ResBlock = ResBlock_do_fft_bench_eval

        # Encoder components
        self.encoder = nn.ModuleList([
            EncoderBlock(base_channel, num_res, ResBlock=ResBlock),
            EncoderBlock(base_channel * 2, num_res, ResBlock=ResBlock),
            EncoderBlock(base_channel * 4, num_res, ResBlock=ResBlock),
        ])

        # Feature extraction path
        self.feature_extractor = nn.ModuleList([
            BasicConv(3, base_channel, kernel_size=3, relu=True, stride=1),
            BasicConv(base_channel, base_channel * 2, kernel_size=3, relu=True, stride=2),
            BasicConv(base_channel * 2, base_channel * 4, kernel_size=3, relu=True, stride=2),
            BasicConv(base_channel * 4, base_channel * 2, kernel_size=4, relu=True, stride=2, transpose=True),
            BasicConv(base_channel * 2, base_channel, kernel_size=4, relu=True, stride=2, transpose=True),
            BasicConv(base_channel, 3, kernel_size=3, relu=False, stride=1)
        ])

        # Decoder components
        self.decoder = nn.ModuleList([
            DecoderBlock(base_channel * 4, num_res, ResBlock=ResBlock),
            DecoderBlock(base_channel * 2, num_res, ResBlock=ResBlock),
            DecoderBlock(base_channel, num_res, ResBlock=ResBlock)
        ])

        # Additional components
        self.feature_fusions = nn.ModuleList([
            FeatureFusion(base_channel * 7, base_channel * 1, BasicConv=BasicConv),
            FeatureFusion(base_channel * 7, base_channel * 2, BasicConv=BasicConv)
        ])

        self.channel_reducers = nn.ModuleList([
            BasicConv(base_channel * 4, base_channel * 2, kernel_size=1, relu=True, stride=1),
            BasicConv(base_channel * 2, base_channel, kernel_size=1, relu=True, stride=1),
        ])

        self.output_converters = nn.ModuleList([
            BasicConv(base_channel * 4, 3, kernel_size=3, relu=False, stride=1),
            BasicConv(base_channel * 2, 3, kernel_size=3, relu=False, stride=1),
        ])

        self.feature_attention1 = FeatureAttention(base_channel * 4, BasicConv=BasicConv)
        self.shallow_feature1 = ShallowFeatureExtractor(base_channel * 4, BasicConv=BasicConv)
        self.feature_attention2 = FeatureAttention(base_channel * 2, BasicConv=BasicConv)
        self.shallow_feature2 = ShallowFeatureExtractor(base_channel * 2, BasicConv=BasicConv)

    def forward(self, x):
        # Downsample inputs
        x_half = F.interpolate(x, scale_factor=0.5)
        x_quarter = F.interpolate(x_half, scale_factor=0.5)

        # Extract shallow features
        shallow_feat_half = self.shallow_feature2(x_half)
        shallow_feat_quarter = self.shallow_feature1(x_quarter)

        outputs = []

        # Encoder path
        x_ = self.feature_extractor[0](x)
        res1 = self.encoder[0](x_)

        z = self.feature_extractor[1](res1)
        z = self.feature_attention2(z, shallow_feat_half)
        res2 = self.encoder[1](z)

        z = self.feature_extractor[2](res2)
        z = self.feature_attention1(z, shallow_feat_quarter)
        z = self.encoder[2](z)

        # Feature fusion
        res1_half = F.interpolate(res1, scale_factor=0.5)
        res2_double = F.interpolate(res2, scale_factor=2)
        z_double = F.interpolate(z, scale_factor=2)
        z_quadruple = F.interpolate(z_double, scale_factor=2)

        res2 = self.feature_fusions[1](res1_half, res2, z_double)
        res1 = self.feature_fusions[0](res1, res2_double, z_quadruple)

        # Decoder path
        z = self.decoder[0](z)
        z_ = self.output_converters[0](z)
        z = self.feature_extractor[3](z)
        if not self.inference:
            outputs.append(z_ + x_quarter)

        z = torch.cat([z, res2], dim=1)
        z = self.channel_reducers[0](z)
        z = self.decoder[1](z)
        z_ = self.output_converters[1](z)
        z = self.feature_extractor[4](z)
        if not self.inference:
            outputs.append(z_ + x_half)

        z = torch.cat([z, res1], dim=1)
        z = self.channel_reducers[1](z)
        z = self.decoder[2](z)
        z = self.feature_extractor[5](z)

        if not self.inference:
            outputs.append(z + x)
            return outputs[::-1]
        else:
            return z + x


class DeepRFT(DeepRFTBase):
    def __init__(self, num_res=8, inference=False):
        super().__init__(num_res=num_res, inference=inference)


class DeepRFTSmall(DeepRFTBase):
    def __init__(self, num_res=4, inference=False):
        super().__init__(num_res=num_res, inference=inference)


class DeepRFTPlus(DeepRFTBase):
    def __init__(self, num_res=20, inference=False):
        super().__init__(num_res=num_res, inference=inference)


class DeepRFTFlops(DeepRFTBase):
    def __init__(self, num_res=8, inference=True):
        super().__init__(num_res=num_res, inference=inference)