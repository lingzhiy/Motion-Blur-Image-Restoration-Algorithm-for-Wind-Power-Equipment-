import os
import argparse
import random
import time
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
import kornia
from tqdm import tqdm

from data_loader import get_training_set, get_validation_set
from model import DeepImageRestorationNetwork
from loss_functions import CharbonnierLoss, EdgeAwareLoss, FrequencyDomainLoss
from utils import (
    create_directory,
    load_checkpoint,
    save_checkpoint,
    calculate_psnr,
    set_random_seeds,
    configure_gpus
)


def parse_arguments():
    parser = argparse.ArgumentParser(description='Image Deblurring Training')
    parser.add_argument('--train_dir', default='./Datasets/GoPro/train',
                        type=str, help='Training dataset directory')
    parser.add_argument('--val_dir', default='./Datasets/GoPro/val',
                        type=str, help='Validation dataset directory')
    parser.add_argument('--model_save_dir', default='./checkpoints',
                        type=str, help='Model checkpoint directory')
    parser.add_argument('--pretrain_weights', default='./checkpoints/model_best.pth',
                        type=str, help='Pretrained weights path')
    parser.add_argument('--task_mode', default='Deblurring',
                        type=str, help='Task mode')
    parser.add_argument('--session_name', default='DeepRFT_gopro',
                        type=str, help='Training session name')
    parser.add_argument('--patch_size', default=256, type=int,
                        help='Training patch size')
    parser.add_argument('--num_epochs', default=3000, type=int,
                        help='Number of training epochs')
    parser.add_argument('--batch_size', default=16, type=int,
                        help='Training batch size')
    parser.add_argument('--val_interval', default=20, type=int,
                        help='Validation interval in epochs')
    return parser.parse_args()


def initialize_training(args):
    set_random_seeds(1234)
    configure_gpus('0,1')

    model = DeepImageRestorationNetwork()
    model.cuda()

    if torch.cuda.device_count() > 1:
        print(f"Using {torch.cuda.device_count()} GPUs for training")
        model = nn.DataParallel(model)

    optimizer = optim.Adam(model.parameters(), lr=2e-4, betas=(0.9, 0.999), eps=1e-8)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, args.num_epochs, eta_min=1e-6)

    return model, optimizer, scheduler


def train_epoch(model, train_loader, optimizer, loss_functions):
    model.train()
    total_loss = 0

    for batch in tqdm(train_loader):
        optimizer.zero_grad()

        sharp_images = batch[0].cuda()
        blur_images = batch[1].cuda()
        sharp_pyramid = kornia.geometry.transform.build_pyramid(sharp_images, 3)

        restored_pyramid = model(blur_images)

        fft_loss = sum(loss_functions['fft'](r, t) for r, t in zip(restored_pyramid, sharp_pyramid))
        char_loss = sum(loss_functions['char'](r, t) for r, t in zip(restored_pyramid, sharp_pyramid))
        edge_loss = sum(loss_functions['edge'](r, t) for r, t in zip(restored_pyramid, sharp_pyramid))

        loss = char_loss + 0.01 * fft_loss + 0.05 * edge_loss
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

    return total_loss / len(train_loader)


def validate_model(model, val_loader):
    model.eval()
    psnr_values = []

    for batch in val_loader:
        sharp_images = batch[0].cuda()
        blur_images = batch[1].cuda()

        with torch.no_grad():
            restored_images = model(blur_images)[0]

        for restored, sharp in zip(restored_images, sharp_images):
            psnr_values.append(calculate_psnr(restored, sharp))

    return torch.stack(psnr_values).mean().item()


def main():
    args = parse_arguments()

    model_dir = os.path.join(args.model_save_dir, args.task_mode, 'models', args.session_name)
    create_directory(model_dir)

    model, optimizer, scheduler = initialize_training(args)
    writer = SummaryWriter(model_dir)

    train_set = get_training_set(args.train_dir, {'patch_size': args.patch_size})
    val_set = get_validation_set(args.val_dir, {'patch_size': args.patch_size})

    train_loader = DataLoader(
        dataset=train_set,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=8,
        pin_memory=True,
        drop_last=False
    )

    val_loader = DataLoader(
        dataset=val_set,
        batch_size=16,
        shuffle=False,
        num_workers=8,
        pin_memory=True,
        drop_last=False
    )

    loss_functions = {
        'char': CharbonnierLoss(),
        'edge': EdgeAwareLoss(),
        'fft': FrequencyDomainLoss()
    }

    best_psnr = 0
    best_epoch = 0

    for epoch in range(1, args.num_epochs + 1):
        start_time = time.time()

        # Training phase
        epoch_loss = train_epoch(model, train_loader, optimizer, loss_functions)
        writer.add_scalar('Loss/Train', epoch_loss, epoch)

        # Validation phase
        if epoch % args.val_interval == 0:
            current_psnr = validate_model(model, val_loader)
            writer.add_scalar('Metrics/PSNR', current_psnr, epoch)

            if current_psnr > best_psnr:
                best_psnr = current_psnr
                best_epoch = epoch
                save_checkpoint(
                    model_dir,
                    'model_best.pth',
                    epoch,
                    model,
                    optimizer
                )

            print(f"Epoch {epoch}: PSNR={current_psnr:.4f} (Best: {best_psnr:.4f} @ Epoch {best_epoch})")

        # Save checkpoints
        save_checkpoint(
            model_dir,
            f'model_epoch_{epoch}.pth',
            epoch,
            model,
            optimizer
        )

        save_checkpoint(
            model_dir,
            'model_latest.pth',
            epoch,
            model,
            optimizer
        )

        scheduler.step()

        epoch_time = time.time() - start_time
        print(
            f"Epoch {epoch} completed in {epoch_time:.2f}s - Loss: {epoch_loss:.4f} - LR: {scheduler.get_lr()[0]:.6f}")

    writer.close()


if __name__ == '__main__':
    main()