import os
import argparse
import time
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm import tqdm

from data_loader import get_test_dataset
from model import DeepImageRestorationNetwork
from model_utils import count_parameters
from window_operations import partition_into_windows, reconstruct_from_windows


def parse_arguments():
    parser = argparse.ArgumentParser(description='Image Deblurring Benchmark')
    parser.add_argument('--input_dir', default='./Datasets/GoPro/test/blur',
                        type=str, help='Path to input test images')
    parser.add_argument('--gpus', default='0',
                        type=str, help='GPU device IDs to use')
    return parser.parse_args()


def setup_environment(gpu_ids):
    os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
    os.environ["CUDA_VISIBLE_DEVICES"] = gpu_ids


def initialize_model():
    model = DeepImageRestorationNetwork()
    count_parameters(model)
    model = nn.DataParallel(model.cuda()).eval()
    return model


def benchmark_model(model, test_loader, window_size=256):
    total_time = 0.0

    with torch.no_grad():
        for batch_data in tqdm(test_loader):
            torch.cuda.empty_cache()

            input_tensor = batch_data[0].cuda()
            batch, _, height, width = input_tensor.shape

            torch.cuda.synchronize()
            start_time = time.time()

            windowed_input, batch_info = partition_into_windows(input_tensor, window_size)
            output = model(windowed_input)
            restored = reconstruct_from_windows(output[0], window_size, height, width, batch_info)
            restored = torch.clamp(restored, 0, 1)

            torch.cuda.synchronize()
            total_time += time.time() - start_time

    average_time = total_time / len(test_loader.dataset)
    print(f'Average processing time: {average_time:.4f} seconds per image')


def main():
    args = parse_arguments()
    setup_environment(args.gpus)

    model = initialize_model()
    test_dataset = get_test_dataset(args.input_dir)
    test_loader = DataLoader(
        dataset=test_dataset,
        batch_size=1,
        shuffle=False,
        num_workers=4,
        pin_memory=True,
        drop_last=False
    )

    benchmark_model(model, test_loader)


if __name__ == '__main__':
    main()