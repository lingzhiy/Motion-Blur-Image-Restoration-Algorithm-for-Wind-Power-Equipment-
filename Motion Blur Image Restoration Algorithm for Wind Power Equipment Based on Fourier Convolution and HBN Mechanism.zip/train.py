import os
import argparse
import random
import time
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
import kornia
from tqdm import tqdm

from data_loader import get_train_dataset, get_val_dataset
from model import DeepImageRestorationModel
from losses import CharbonnierLoss, EdgeAwareLoss, FrequencyDomainLoss
from utils import (
    setup_directories,
    load_pretrained_weights,
    save_checkpoint,
    calculate_psnr,
    set_random_seeds,
    configure_gpu
)
from scheduler import GradualWarmupScheduler


def parse_arguments():
    parser = argparse.ArgumentParser(description='Image Deblurring Training')
    parser.add_argument('--train_dir', required=True, type=str, help='Training data directory')
    parser.add_argument('--val_dir', required=True, type=str, help='Validation data directory')
    parser.add_argument('--model_save_dir', default='./checkpoints', type=str, help='Model save directory')
    parser.add_argument('--pretrain_weights', type=str, help='Pretrained weights path')
    parser.add_argument('--task_mode', default='Deblurring', type=str, help='Task mode')
    parser.add_argument('--session_name', default='experiment', type=str, help='Training session name')
    parser.add_argument('--patch_size', default=256, type=int, help='Training patch size')
    parser.add_argument('--num_epochs', default=1500, type=int, help='Number of training epochs')
    parser.add_argument('--batch_size', default=2, type=int, help='Training batch size')
    parser.add_argument('--val_interval', default=1, type=int, help='Validation interval in epochs')
    return parser.parse_args()


def initialize_model(device_ids):
    model = DeepImageRestorationModel()
    if len(device_ids) > 1:
        print(f"Using {len(device_ids)} GPUs for training")
        model = nn.DataParallel(model, device_ids=device_ids)
    return model.cuda()


def create_data_loaders(train_dir, val_dir, patch_size, batch_size):
    train_dataset = get_train_dataset(train_dir, {'patch_size': patch_size})
    val_dataset = get_val_dataset(val_dir, {'patch_size': patch_size})

    train_loader = DataLoader(
        dataset=train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=4,
        pin_memory=True,
        drop_last=False
    )

    val_loader = DataLoader(
        dataset=val_dataset,
        batch_size=8,
        shuffle=False,
        num_workers=4,
        pin_memory=True,
        drop_last=False
    )

    return train_loader, val_loader


def train_epoch(model, train_loader, optimizer, loss_functions):
    model.train()
    epoch_loss = 0.0

    for batch_data in tqdm(train_loader):
        optimizer.zero_grad()

        target_images = batch_data[0].cuda()
        input_images = batch_data[1].cuda()
        target_pyramid = kornia.geometry.transform.build_pyramid(target_images, 3)

        restored_pyramid = model(input_images)

        # Calculate losses
        fft_loss = sum(loss_functions['fft'](r, t) for r, t in zip(restored_pyramid, target_pyramid))
        char_loss = sum(loss_functions['char'](r, t) for r, t in zip(restored_pyramid, target_pyramid))
        edge_loss = sum(loss_functions['edge'](r, t) for r, t in zip(restored_pyramid, target_pyramid))

        total_loss = char_loss + 0.01 * fft_loss + 0.05 * edge_loss
        total_loss.backward()
        optimizer.step()

        epoch_loss += total_loss.item()

    return epoch_loss


def validate_model(model, val_loader):
    model.eval()
    psnr_values = []

    for val_data in val_loader:
        target_images = val_data[0].cuda()
        input_images = val_data[1].cuda()

        with torch.no_grad():
            restored_images = model(input_images)[0]

        for res_img, tar_img in zip(restored_images, target_images):
            psnr_values.append(calculate_psnr(res_img, tar_img))

    return torch.stack(psnr_values).mean().item()


def main():
    args = parse_arguments()
    set_random_seeds(1234)
    configure_gpu('0,1')

    model_dir = setup_directories(args.model_save_dir, args.task_mode, args.session_name)
    writer = SummaryWriter(model_dir)

    device_ids = list(range(torch.cuda.device_count()))
    model = initialize_model(device_ids)

    optimizer = optim.Adam(model.parameters(), lr=2e-4, betas=(0.9, 0.999), eps=1e-8)

    # Learning rate scheduler
    warmup_epochs = 3
    cosine_scheduler = optim.lr_scheduler.CosineAnnealingLR(
        optimizer,
        args.num_epochs - warmup_epochs,
        eta_min=1e-6
    )
    scheduler = GradualWarmupScheduler(
        optimizer,
        multiplier=1,
        total_epoch=warmup_epochs,
        after_scheduler=cosine_scheduler
    )

    # Loss functions
    loss_functions = {
        'char': CharbonnierLoss(),
        'edge': EdgeAwareLoss(),
        'fft': FrequencyDomainLoss()
    }

    train_loader, val_loader = create_data_loaders(
        args.train_dir,
        args.val_dir,
        args.patch_size,
        args.batch_size
    )

    best_psnr = 0.0
    best_epoch = 0

    for epoch in range(1, args.num_epochs + 1):
        epoch_start = time.time()

        # Training phase
        epoch_loss = train_epoch(model, train_loader, optimizer, loss_functions)
        writer.add_scalar('Loss/train', epoch_loss, epoch)

        # Validation phase
        if epoch % args.val_interval == 0:
            current_psnr = validate_model(model, val_loader)
            writer.add_scalar('Metrics/val_psnr', current_psnr, epoch)

            if current_psnr > best_psnr:
                best_psnr = current_psnr
                best_epoch = epoch
                save_checkpoint(
                    model_dir,
                    'model_best.pth',
                    epoch,
                    model,
                    optimizer
                )

            print(f"Epoch {epoch} PSNR: {current_psnr:.4f} "
                  f"(Best: {best_psnr:.4f} @ epoch {best_epoch})")

        # Save checkpoints
        save_checkpoint(
            model_dir,
            f'model_epoch_{epoch}.pth',
            epoch,
            model,
            optimizer
        )
        save_checkpoint(
            model_dir,
            'model_latest.pth',
            epoch,
            model,
            optimizer
        )

        scheduler.step()

        epoch_time = time.time() - epoch_start
        print(f"Epoch {epoch} completed in {epoch_time:.2f}s - "
              f"Loss: {epoch_loss:.4f} - LR: {scheduler.get_lr()[0]:.6f}")

    writer.close()


if __name__ == '__main__':
    main()