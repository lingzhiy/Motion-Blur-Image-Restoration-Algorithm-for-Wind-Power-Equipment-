import os
import argparse
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from skimage import img_as_ubyte
from skimage.metrics import peak_signal_noise_ratio as psnr_metric
import cv2
from tqdm import tqdm

from model_architectures import DeepImageRestoration
from data_processing import get_test_dataset
from utilities import create_directory, save_image, load_model_weights
from parameter_counter import count_model_parameters
from window_operations import partition_image, reconstruct_image


def parse_arguments():
    parser = argparse.ArgumentParser(description='Image Deblurring Inference')
    parser.add_argument('--input_dir', required=True, type=str, help='Path to input images')
    parser.add_argument('--target_dir', type=str, help='Path to ground truth images')
    parser.add_argument('--output_dir', default='./results', type=str, help='Path to save results')
    parser.add_argument('--weights', required=True, type=str, help='Path to model weights')
    parser.add_argument('--compute_metrics', default=False, type=bool, help='Calculate PSNR/SSIM')
    parser.add_argument('--gpu_id', default='0', type=str, help='GPU device ID')
    parser.add_argument('--save_results', default=True, type=bool, help='Save output images')
    parser.add_argument('--window_size', default=256, type=int, help='Processing window size')
    parser.add_argument('--residual_blocks', default=8, type=int, help='Number of residual blocks')
    return parser.parse_args()


def setup_environment(gpu_id):
    os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
    os.environ["CUDA_VISIBLE_DEVICES"] = gpu_id


def initialize_model(num_blocks, weights_path):
    model = DeepImageRestoration(num_residual_blocks=num_blocks, inference_mode=True)
    count_model_parameters(model)
    load_model_weights(model, weights_path)
    model = nn.DataParallel(model.cuda()).eval()
    return model


def process_batch(model, input_batch, window_size):
    batch, _, height, width = input_batch.shape
    partitioned, batch_info = partition_image(input_batch, window_size)
    restored = model(partitioned)
    return reconstruct_image(restored, window_size, height, width, batch_info)


def evaluate_model(args):
    setup_environment(args.gpu_id)
    model = initialize_model(args.residual_blocks, args.weights)
    test_loader = DataLoader(
        dataset=get_test_dataset(args.input_dir),
        batch_size=1,
        shuffle=False,
        num_workers=0,
        pin_memory=True
    )

    create_directory(args.output_dir)
    metric_values = []

    with torch.no_grad():
        for data in tqdm(test_loader):
            torch.cuda.empty_cache()
            input_tensor, filenames = data[0].cuda(), data[1]

            output_tensor = process_batch(model, input_tensor, args.window_size)
            output_tensor = torch.clamp(output_tensor, 0, 1)
            output_images = output_tensor.permute(0, 2, 3, 1).cpu().numpy()

            for idx, image in enumerate(output_images):
                processed_image = img_as_ubyte(image)
                if args.compute_metrics:
                    ground_truth = cv2.imread(os.path.join(args.target_dir, filenames[idx] + '.png'))
                    ground_truth = cv2.cvtColor(ground_truth, cv2.COLOR_BGR2RGB)
                    metric_values.append(psnr_metric(processed_image, ground_truth))

                if args.save_results:
                    save_image(os.path.join(args.output_dir, filenames[idx] + '.png'), processed_image)

    if args.compute_metrics and metric_values:
        average_psnr = sum(metric_values) / len(metric_values)
        print(f"Average PSNR: {average_psnr:.4f}")


if __name__ == '__main__':
    configuration = parse_arguments()
    evaluate_model(configuration)