import numpy as np
import torch
from ptflops import get_model_complexity_info


def calculate_parameters(model):
    total_params = sum(np.prod(p.size()) for p in model.parameters())
    trainable_params = sum(np.prod(p.size()) for p in model.parameters() if p.requires_grad)
    print(f'Total parameters: {total_params}')
    print(f'Trainable parameters: {trainable_params}')


class ModelAnalyzer:
    @staticmethod
    def analyze(model_class, input_shape=(3, 256, 256)):
        device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

        with torch.cuda.device(0):
            model = model_class().to(device)
            calculate_parameters(model)

            flops, params = get_model_complexity_info(
                model,
                input_shape,
                as_strings=True,
                print_per_layer_stat=True,
                verbose=True
            )

            print(f"{'Computational complexity:':<30} {flops:<8}")
            print(f"{'Number of parameters:':<30} {params:<8}")


if __name__ == '__main__':
    from DeepRFT_MIMO import DeepRFT_flops as NetworkModel

    ModelAnalyzer.analyze(NetworkModel)
