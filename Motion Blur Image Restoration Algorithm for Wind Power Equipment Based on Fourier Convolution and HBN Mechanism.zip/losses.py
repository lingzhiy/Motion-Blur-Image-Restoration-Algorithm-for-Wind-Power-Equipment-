import torch
import torch.nn as nn
import torch.nn.functional as F

class RobustL1Loss(nn.Module):
    def __init__(self, epsilon=1e-3):
        super().__init__()
        self.epsilon = epsilon

    def forward(self, prediction, target):
        difference = prediction - target
        return torch.mean(torch.sqrt((difference ** 2) + (self.epsilon ** 2)))

class EdgeAwareLoss(nn.Module):
    def __init__(self):
        super().__init__()
        kernel = torch.Tensor([[0.05, 0.25, 0.4, 0.25, 0.05]])
        self.gaussian_kernel = torch.matmul(kernel.t(), kernel).unsqueeze(0).repeat(3, 1, 1, 1)
        if torch.cuda.is_available():
            self.gaussian_kernel = self.gaussian_kernel.cuda()
        self.loss_function = RobustL1Loss()

    def apply_gaussian_filter(self, image):
        channels, _, width, height = self.gaussian_kernel.shape
        padded = F.pad(image, (width//2, height//2, width//2, height//2), mode='replicate')
        return F.conv2d(padded, self.gaussian_kernel, groups=channels)

    def compute_laplacian(self, image):
        filtered = self.apply_gaussian_filter(image)
        downsampled = filtered[:, :, ::2, ::2]
        upsampled = torch.zeros_like(filtered)
        upsampled[:, :, ::2, ::2] = downsampled * 4
        reconstructed = self.apply_gaussian_filter(upsampled)
        return image - reconstructed

    def forward(self, prediction, target):
        pred_laplacian = self.compute_laplacian(prediction)
        target_laplacian = self.compute_laplacian(target)
        return self.loss_function(pred_laplacian, target_laplacian)

class FrequencyDomainLoss(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, prediction, target):
        pred_fft = torch.fft.fft2(prediction)
        target_fft = torch.fft.fft2(target)
        spectral_difference = torch.abs(pred_fft - target_fft)
        return torch.mean(spectral_difference)